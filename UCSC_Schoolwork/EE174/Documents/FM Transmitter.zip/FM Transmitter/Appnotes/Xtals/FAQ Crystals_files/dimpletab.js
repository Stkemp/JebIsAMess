//�Xara Ltd
if(typeof(loc)=="undefined"||loc==""){var loc="";if(document.body&&document.body.innerHTML){var tt=document.body.innerHTML;var ml=tt.match(/["']([^'"]*)dimpletab.js["']/i);if(ml && ml.length > 1) loc=ml[1];}}

var bd=0
document.write("<style type=\"text/css\">");
document.write("\n<!--\n");
document.write(".dimpletab_menu {z-index:999;border-color:#ffffff;border-style:solid;border-width:"+bd+"px 0px "+bd+"px 0px;background-color:#003366;position:absolute;left:0px;top:0px;visibility:hidden;}");
document.write(".dimpletab_plain, a.dimpletab_plain:link, a.dimpletab_plain:visited{text-align:left;background-color:#003366;color:#ffffff;text-decoration:none;border-color:#ffffff;border-style:solid;border-width:0px "+bd+"px 0px "+bd+"px;padding:2px 0px 2px 0px;cursor:hand;display:block;font-size:9pt;font-family:Verdana, Arial, Helvetica, sans-serif;}");
document.write("a.dimpletab_plain:hover, a.dimpletab_plain:active{background-color:#3085bf;color:#ffffff;text-decoration:none;border-color:#ffffff;border-style:solid;border-width:0px "+bd+"px 0px "+bd+"px;padding:2px 0px 2px 0px;cursor:hand;display:block;font-size:9pt;font-family:Verdana, Arial, Helvetica, sans-serif;}");
document.write("a.dimpletab_l:link, a.dimpletab_l:visited{text-align:left;background:#003366 url("+loc+"dimpletab_l.gif) no-repeat right;color:#ffffff;text-decoration:none;border-color:#ffffff;border-style:solid;border-width:0px "+bd+"px 0px "+bd+"px;padding:2px 0px 2px 0px;cursor:hand;display:block;font-size:9pt;font-family:Verdana, Arial, Helvetica, sans-serif;}");
document.write("a.dimpletab_l:hover, a.dimpletab_l:active{background:#3085bf url("+loc+"dimpletab_l.gif) no-repeat right;color: #ffffff;text-decoration:none;border-color:#ffffff;border-style:solid;border-width:0px "+bd+"px 0px "+bd+"px;padding:2px 0px 2px 0px;cursor:hand;display:block;font-size:9pt;font-family:Verdana, Arial, Helvetica, sans-serif;}");
document.write("\n-->\n");
document.write("</style>");

var fc=0xffffff;
var bc=0x3085bf;
if(typeof(frames)=="undefined"){var frames=0;}

startMainMenu("dimpletab_left.gif",11,8,2,0,0)
mainMenuItem("dimpletab_b1",".gif",21,65,"javascript:;","","Products",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b2",".gif",21,85,"javascript:;","","Product Info",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b3",".gif",21,215,"javascript:;","","Design Guides / Reference Material",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b4",".gif",21,118,"javascript:;","","Quotes / Samples",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b5",".gif",21,68,"javascript:;","","About Us",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b6",".gif",21,78,"http://foxonline.com/email.htm","","Contact Us",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b7",".gif",21,55,"http://foxonline.com/forms/sitesearch.htm","","Search",2,2,"dimpletab_plain");
mainMenuItem("dimpletab_b8",".gif",21,50,"http://www.foxonline.com","","Home",2,2,"dimpletab_plain");
endMainMenu("dimpletab_right.gif",11,8)

startSubmenu("dimpletab_b5","dimpletab_menu",150);
submenuItem("Press Releases","http://foxonline.com/whatsnew.htm","","dimpletab_plain");
submenuItem("FOX Facts","http://foxonline.com/news.htm","","dimpletab_plain");
submenuItem("Reps and Distributors","http://foxonline.com/repdisty.htm","","dimpletab_plain");
submenuItem("Contact Us","http://foxonline.com/email.htm","","dimpletab_plain");
submenuItem("PartnerNet","http://foxonline.com/Forms/gopartner.asp","","dimpletab_plain");
endSubmenu("dimpletab_b5");

startSubmenu("dimpletab_b4","dimpletab_menu",171);
submenuItem("Crystals","http://foxonline.com/form_crystal.htm","","dimpletab_plain");
submenuItem("Oscillators","http://foxonline.com/form_oscillator.htm","","dimpletab_plain");
submenuItem("JITO�-2","http://foxonline.com/form_jito2.htm","","dimpletab_plain");
submenuItem("TCXO, VCXO, OCXO, rfXO","http://foxonline.com/form_tcxovcxo.htm","","dimpletab_plain");
submenuItem("Contact Us","http://foxonline.com/email.htm","","dimpletab_plain");
endSubmenu("dimpletab_b4");

startSubmenu("dimpletab_b3_1","dimpletab_menu",235);
submenuItem("Quartz Crystal Theory of Operation","http://foxonline.com/pdfs/xtaltheoryoper.pdf","","dimpletab_plain");
submenuItem("Crystal Design Notes","http://foxonline.com/pdfs/xtaldesignnotes.pdf","","dimpletab_plain");
submenuItem("Tuning Forks","http://foxonline.com/appnotes.htm","","dimpletab_plain");
submenuItem("Oscillators Theory of Operation","http://foxonline.com/pdfs/osctheoryoper.pdf","","dimpletab_plain");
endSubmenu("dimpletab_b3_1");

startSubmenu("dimpletab_b3","dimpletab_menu",215);
mainMenuItem("dimpletab_b3_1","Application Notes",0,0,"javascript:;","","",1,1,"dimpletab_l");
submenuItem("Frequently Asked Questions","http://foxonline.com/techfaqs.htm","","dimpletab_plain");
submenuItem("Glossary of Terms","http://foxonline.com/tgcrystals.htm","","dimpletab_plain");
submenuItem("Chipset Refererence Table","http://foxonline.com/Chipsets/chipset_main.htm","","dimpletab_plain");
submenuItem("Articles of Interest","http://foxonline.com/techart.htm","","dimpletab_plain");
submenuItem("Recommending Reading","http://foxonline.com/oscbooks.htm","","dimpletab_plain");
endSubmenu("dimpletab_b3");

startSubmenu("dimpletab_b2_2","dimpletab_menu",245);
submenuItem("Tape and Reel SMD Crystals","http://foxonline.com/crytrspc.pdf","","dimpletab_plain");
submenuItem("Tape and Reel SMD Oscillators","http://foxonline.com/osctrspc.pdf","","dimpletab_plain");
submenuItem("Environmental and Mechanical Specs","http://foxonline.com/genchrtr.htm","","dimpletab_plain");
endSubmenu("dimpletab_b2_2");

startSubmenu("dimpletab_b2","dimpletab_menu",317);
submenuItem("Part Marking Guide","http://foxonline.com/Partmarkings/PM_TOC2.htm","","dimpletab_plain");
mainMenuItem("dimpletab_b2_2","Packing,Environmental and Mechanical Specs",0,0,"javascript:;","","",1,1,"dimpletab_l");
submenuItem("Engineering Change Notices","http://foxonline.com/ecn.htm","","dimpletab_plain");
submenuItem("Distributor Stock Locator","http://dilp.netcomponents.com/fox.html","","dimpletab_plain");
submenuItem("Part Number Guide","http://foxonline.com/onefamilytype.asp","","dimpletab_plain");
submenuItem("Pb Free Matrix","http://foxonline.com/pdfs/PbFreeMatrix.htm","","dimpletab_plain");
submenuItem("Pb Free Solder Reflow Profile","http://foxonline.com/pdfs/1607PbFreeSolderReflowProfile.pdf","","dimpletab_plain");
endSubmenu("dimpletab_b2");

startSubmenu("dimpletab_b1_9","dimpletab_menu",146);
submenuItem("Surface Mount Filters","http://foxonline.com/filters_smt.htm","","dimpletab_plain");
submenuItem("Thru-hole Filters","http://foxonline.com/filters.htm","","dimpletab_plain");
endSubmenu("dimpletab_b1_9");

startSubmenu("dimpletab_b1_8","dimpletab_menu",152);
submenuItem("Surface Mount OCXOs","http://foxonline.com/ocxo_smd.htm","","dimpletab_plain");
submenuItem("Thru-Hole OCXOs","http://foxonline.com/ocxoindx.htm","","dimpletab_plain");
endSubmenu("dimpletab_b1_8");

startSubmenu("dimpletab_b1_7","dimpletab_menu",193);
submenuItem("Surface Mount VCXOs","http://foxonline.com/vcxo_smd.htm","","dimpletab_plain");
submenuItem("Thru-Hole VCXOs","http://foxonline.com/vcxo_thruhole.htm","","dimpletab_plain");
submenuItem("Standard Stocking VCXOs","http://foxonline.com/foxstandards.htm","","dimpletab_plain");
submenuItem("VCXO Part Description Guide","http://foxonline.com/pdfs/tcvcpartdesc.pdf","","dimpletab_plain");
endSubmenu("dimpletab_b1_7");

startSubmenu("dimpletab_b1_6","dimpletab_menu",192);
submenuItem("Surface Mount TCXOs","http://foxonline.com/tcxoindx.htm","","dimpletab_plain");
submenuItem("Thru-Hole TCXOs","http://foxonline.com/tcxoindx_thruhole.htm","","dimpletab_plain");
submenuItem("Standard Stocking TCXOs","http://foxonline.com/foxstandards.htm","","dimpletab_plain");
submenuItem("TCXO Part Description Guide","http://foxonline.com/pdfs/tcvcpartdesc.pdf","","dimpletab_plain");
endSubmenu("dimpletab_b1_6");

startSubmenu("dimpletab_b1_5","dimpletab_menu",185);
submenuItem("rfXO Main Page","http://foxonline.com/rfxoseries2.htm","","dimpletab_plain");
submenuItem("rfXO Part Description Guide","http://foxonline.com/pdfs/tcvcpartdesc.pdf","","dimpletab_plain");
endSubmenu("dimpletab_b1_5");

startSubmenu("dimpletab_b1_4","dimpletab_menu",214);
submenuItem("JITO�-2 Main page","http://foxonline.com/jitomain.htm","","dimpletab_plain");
submenuItem("JITO�-2 Part Description Guide ","http://foxonline.com/jitorgui.htm","","dimpletab_plain");
endSubmenu("dimpletab_b1_4");

startSubmenu("dimpletab_b1_3","dimpletab_menu",216);
submenuItem("Surface Mount Oscillators","http://foxonline.com/smd_osc.htm","","dimpletab_plain");
submenuItem("Thru-Hole Oscillators","http://foxonline.com/thruhole_osc.htm","","dimpletab_plain");
submenuItem("Standard Stocking Oscillators","http://foxonline.com/foxstandards.htm","","dimpletab_plain");
submenuItem("Oscillator Part Description Guide","http://foxonline.com/pdfs/oscpartdesc.pdf","","dimpletab_plain");
endSubmenu("dimpletab_b1_3");

startSubmenu("dimpletab_b1_2","dimpletab_menu",202);
submenuItem("Surface Mount Crystals","http://foxonline.com/smd_xtals.htm","","dimpletab_plain");
submenuItem("Thru-hole Crystals","http://foxonline.com/thruhole_xtals.htm","","dimpletab_plain");
submenuItem("Tuning Fork Watch Crystals","http://foxonline.com/watchxtals.htm","","dimpletab_plain");
submenuItem("Standard Stocking Crystals","http://foxonline.com/foxstandards.htm","","dimpletab_plain");
submenuItem("Crystal Part Description Guide","http://foxonline.com/pdfs/xtalpartdesc.pdf","","dimpletab_plain");
endSubmenu("dimpletab_b1_2");

startSubmenu("dimpletab_b1","dimpletab_menu",238);
submenuItem("General Selection Guide","http://foxonline.com/products.htm","","dimpletab_plain");
mainMenuItem("dimpletab_b1_2","Crystals 32.768kHz ~ 160MHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
mainMenuItem("dimpletab_b1_3","Oscillators 144kHz ~ 1.25GHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
mainMenuItem("dimpletab_b1_4","JITO�-2 144kHz ~ 300MHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
mainMenuItem("dimpletab_b1_5","rfXOs 600 ~ 1.25GHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
mainMenuItem("dimpletab_b1_6","TCXOs 8MHz ~ 160MHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
mainMenuItem("dimpletab_b1_7","VCXOs 1MHz ~ 1.25GHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
mainMenuItem("dimpletab_b1_8","OCXOs 5MHz ~ 50MHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
mainMenuItem("dimpletab_b1_9","Crystal Filters 10.7MHz ~ 70MHz",0,0,"javascript:;","","",1,1,"dimpletab_l");
submenuItem("Custom Products Center (CPC)","http://foxonline.com/CTC.htm","","dimpletab_plain");
submenuItem("Fast Fox for Quick Delivery","http://foxonline.com/fftoc.htm","","dimpletab_plain");
submenuItem("Catalog PDF Files","http://foxonline.com/catalog.htm","","dimpletab_plain");
endSubmenu("dimpletab_b1");

loc="";
